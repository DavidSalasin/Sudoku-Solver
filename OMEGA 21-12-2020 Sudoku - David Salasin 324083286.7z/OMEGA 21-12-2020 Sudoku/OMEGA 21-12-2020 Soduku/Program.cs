﻿using System;
using System.Diagnostics;
using System.Threading;


namespace OMEGA_21_12_2020_Soduku
{
    class Program
    {
        /**
         * ! Sudoko Solver !
         * 
         * TO: itamarkn60@gmail.com
         * 
         * BY: David Salasin 324083286 OMEGA COURSE.
         */

        // Main method of the program -> calls LaunchInput() from the 
        // static Class SudokuPannel.
        static void Main(string[] args)
        {
            SudokuPannel.LaunchInput();
        }
    }
}
